package nguyenvanquan7826;

/**
 * ----------------- @author nguyenvanquan7826 -----------------
 * ---------------nguyenvanquan7826.wordpress.com --------------
 */
public class MyMain {
	public static void main(String[] args) {
		new MyFrame("Dijkstra Demo");
	}
}
